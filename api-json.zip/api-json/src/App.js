import React, { Component } from 'react'

export default class App extends Component {
  constructor(props){
    super(props)
    this.state = {
      data: []
    }
    this.url = "https://jsonplaceholder.typicode.com/todos";
  }
  async componentWillMount(){
    let data = await fetch(this.url, {
      method: 'GET',
      headers:{ 
      'Content-Type':'application/json',
      'mode': 'no-cors' 
    }
    })
    

    let dataJson = await data.json()
    this.setState({data: dataJson})
  }

  render() {
    return (
      <div>
        <div>{this.state.data.map((dado, index) => {
          return <div style={{display: 'flex', alignItems: 'center'}} key={index}>
              <h2>title: </h2> {dado.title}
            </div>
        })}</div>
      </div>
    )
  }
}

